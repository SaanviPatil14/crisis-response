import { useState, useEffect, useRef, useCallback } from "react";
import {
  AlertTriangle, Shield, Smartphone, Cpu, Radio, Clock, MapPin,
  CheckCircle, XCircle, Activity, Zap, Bell, ChevronRight,
  Lock, Car, ArrowUpRight, Wifi, Battery, Signal, Phone,
  HeartPulse, Siren, Eye, User, Building2, RefreshCw,
  TriangleAlert, CircleDot, Timer, Navigation, Ambulance
} from "lucide-react";

// ─── HELPERS ────────────────────────────────────────────────────────────────
const now = () => new Date().toLocaleTimeString("en-IN", { hour12: false });
const generateId = () => Math.random().toString(36).slice(2, 9);

const INCIDENT_TYPES = {
  GLASS_BREAK: {
    id: "GLASS_BREAK",
    label: "Glass Break Detected",
    sublabel: "Floor 3 — Corridor B",
    payload: { sensor: "ACOUSTIC_001", type: "glass_break", floor: 3, zone: "Corridor B", confidence: 0.94 },
    severity: "HIGH",
    color: "orange",
    icon: "TriangleAlert",
  },
  MEDICAL_FALL: {
    id: "MEDICAL_FALL",
    label: "Suspected Medical Fall",
    sublabel: "Room 412 — 4th Floor",
    payload: { sensor: "PIR_FALL_412", type: "fall_detection", room: "412", floor: 4, heartRate: 38, confidence: 0.97 },
    severity: "CRITICAL",
    color: "red",
    icon: "HeartPulse",
  },
};

const HOSPITAL_PARTNERS = [
  { id: "apollo", name: "Apollo Hospital", wing: "Emergency", eta: 7, distance: "3.2 km", phone: "+91-11-7179-1090" },
  { id: "max", name: "Max Healthcare", wing: "Trauma Center", eta: 11, distance: "5.1 km", phone: "+91-11-2651-5050" },
];

const ACTION_ITEMS = [
  { id: 1, text: "Clear VIP Driveway (Gate 2)", icon: Car, priority: "CRITICAL" },
  { id: 2, text: "Lock Service Elevator 3", icon: Lock, priority: "CRITICAL" },
  { id: 3, text: "Deploy House Physician to Floor 4", icon: User, priority: "HIGH" },
  { id: 4, text: "Alert Duty Manager on duty", icon: Phone, priority: "HIGH" },
  { id: 5, text: "Secure CCTV footage - Corridor 4B", icon: Eye, priority: "MEDIUM" },
];

// ─── STATUS PILL ─────────────────────────────────────────────────────────────
function StatusPill({ status }) {
  const map = {
    IDLE: "bg-slate-700 text-slate-300",
    ALERT: "bg-orange-500/20 text-orange-300 border border-orange-500/50",
    CODE_BLUE: "bg-red-500/20 text-red-300 border border-red-500/50 animate-pulse",
    DISPATCHED: "bg-emerald-500/20 text-emerald-300 border border-emerald-500/50",
  };
  return (
    <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold tracking-widest ${map[status] || map.IDLE}`}>
      {status}
    </span>
  );
}

// ─── IOT SIMULATOR ──────────────────────────────────────────────────────────
function IoTSimulator({ onTrigger, activeAlerts }) {
  const [lastFired, setLastFired] = useState({});
  const [sending, setSending] = useState(null);

  const fire = async (type) => {
    setSending(type);
    await new Promise(r => setTimeout(r, 650));
    const alert = {
      id: generateId(),
      type,
      ...INCIDENT_TYPES[type],
      timestamp: now(),
      rawTime: Date.now(),
      status: "PENDING",
    };
    onTrigger(alert);
    setLastFired(p => ({ ...p, [type]: now() }));
    setSending(null);
  };

  return (
    <div className="h-full bg-slate-950 text-slate-100 flex flex-col">
      {/* Header */}
      <div className="border-b border-slate-800 px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-violet-600/30 flex items-center justify-center border border-violet-500/40">
            <Cpu size={16} className="text-violet-400" />
          </div>
          <div>
            <h2 className="font-mono text-sm font-bold text-slate-100 tracking-wider">IOT SENSOR SIMULATOR</h2>
            <p className="text-xs text-slate-500 font-mono">Developer Control Panel — ENV: STAGING</p>
          </div>
          <div className="ml-auto flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs text-emerald-400 font-mono">MQTT CONNECTED</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Network Topology */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
          <h3 className="text-xs font-mono text-slate-500 tracking-widest mb-3 uppercase">Sensor Network Topology</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "Acoustic", count: 24, active: 24, color: "violet" },
              { label: "PIR / Fall", count: 186, active: 185, color: "blue" },
              { label: "Vitals Bed", count: 12, active: 11, color: "emerald" },
            ].map(s => (
              <div key={s.label} className={`rounded-lg border border-${s.color}-500/20 bg-${s.color}-500/5 p-3`}>
                <div className={`text-lg font-mono font-bold text-${s.color}-400`}>{s.active}<span className="text-xs text-slate-600">/{s.count}</span></div>
                <div className="text-xs text-slate-500 mt-1">{s.label}</div>
                <div className="mt-2 h-1 bg-slate-800 rounded-full overflow-hidden">
                  <div className={`h-full bg-${s.color}-500 rounded-full`} style={{ width: `${(s.active / s.count) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Trigger Buttons */}
        <div className="space-y-3">
          <h3 className="text-xs font-mono text-slate-500 tracking-widest uppercase">Inject Mock Sensor Payload</h3>

          {/* Glass Break */}
          <div className="rounded-xl border border-orange-500/20 bg-orange-500/5 overflow-hidden">
            <div className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <TriangleAlert size={14} className="text-orange-400" />
                    <span className="text-sm font-mono font-bold text-orange-300">Glass Break Event</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1 font-mono">Sensor: ACOUSTIC_001 · Floor 3 · Confidence: 94%</p>
                </div>
                <span className="text-xs bg-orange-500/20 text-orange-400 border border-orange-500/30 px-2 py-0.5 rounded font-mono">HIGH</span>
              </div>
              <div className="bg-slate-950 rounded-lg p-3 mb-3 font-mono text-xs text-slate-400 border border-slate-800">
                <span className="text-violet-400">POST</span> /api/sensor/ingest<br />
                <span className="text-emerald-400">{"{"}</span> type: <span className="text-yellow-400">"glass_break"</span>, floor: <span className="text-sky-400">3</span>, confidence: <span className="text-sky-400">0.94</span> <span className="text-emerald-400">{"}"}</span>
              </div>
              <button
                onClick={() => fire("GLASS_BREAK")}
                disabled={sending === "GLASS_BREAK"}
                className="w-full py-2.5 rounded-lg bg-orange-500 hover:bg-orange-400 text-white font-mono text-sm font-bold tracking-wider transition-all duration-200 disabled:opacity-50 disabled:cursor-wait flex items-center justify-center gap-2"
              >
                {sending === "GLASS_BREAK" ? (
                  <><RefreshCw size={14} className="animate-spin" /> TRANSMITTING...</>
                ) : (
                  <><Zap size={14} /> SIMULATE GLASS BREAK (FLOOR 3)</>
                )}
              </button>
              {lastFired.GLASS_BREAK && (
                <p className="text-xs text-slate-600 font-mono mt-2 text-center">Last fired: {lastFired.GLASS_BREAK}</p>
              )}
            </div>
          </div>

          {/* Medical Fall */}
          <div className="rounded-xl border border-red-500/25 bg-red-500/5 overflow-hidden">
            <div className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <HeartPulse size={14} className="text-red-400" />
                    <span className="text-sm font-mono font-bold text-red-300">Medical Fall Event</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1 font-mono">Sensor: PIR_FALL_412 · Room 412 · HR: 38bpm · Confidence: 97%</p>
                </div>
                <span className="text-xs bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded font-mono">CRITICAL</span>
              </div>
              <div className="bg-slate-950 rounded-lg p-3 mb-3 font-mono text-xs text-slate-400 border border-slate-800">
                <span className="text-violet-400">POST</span> /api/sensor/ingest<br />
                <span className="text-emerald-400">{"{"}</span> type: <span className="text-yellow-400">"fall_detection"</span>, room: <span className="text-yellow-400">"412"</span>, hr: <span className="text-sky-400">38</span> <span className="text-emerald-400">{"}"}</span>
              </div>
              <button
                onClick={() => fire("MEDICAL_FALL")}
                disabled={sending === "MEDICAL_FALL"}
                className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-mono text-sm font-bold tracking-wider transition-all duration-200 disabled:opacity-50 disabled:cursor-wait flex items-center justify-center gap-2"
              >
                {sending === "MEDICAL_FALL" ? (
                  <><RefreshCw size={14} className="animate-spin" /> TRANSMITTING...</>
                ) : (
                  <><HeartPulse size={14} /> SIMULATE FALL — ROOM 412</>
                )}
              </button>
              {lastFired.MEDICAL_FALL && (
                <p className="text-xs text-slate-600 font-mono mt-2 text-center">Last fired: {lastFired.MEDICAL_FALL}</p>
              )}
            </div>
          </div>
        </div>

        {/* Active Alert Queue */}
        <div>
          <h3 className="text-xs font-mono text-slate-500 tracking-widest uppercase mb-3">Active Alert Queue ({activeAlerts.length})</h3>
          {activeAlerts.length === 0 ? (
            <div className="rounded-xl border border-slate-800 bg-slate-900/30 p-6 text-center">
              <CircleDot size={20} className="text-slate-700 mx-auto mb-2" />
              <p className="text-xs text-slate-600 font-mono">No alerts in queue</p>
            </div>
          ) : (
            <div className="space-y-2">
              {activeAlerts.map(a => (
                <div key={a.id} className={`rounded-lg border ${a.type === "MEDICAL_FALL" ? "border-red-500/30 bg-red-500/5" : "border-orange-500/30 bg-orange-500/5"} p-3 flex items-center gap-3`}>
                  <div className={`w-2 h-2 rounded-full ${a.type === "MEDICAL_FALL" ? "bg-red-400" : "bg-orange-400"} animate-pulse`} />
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs font-mono font-bold ${a.type === "MEDICAL_FALL" ? "text-red-300" : "text-orange-300"} truncate`}>{a.label}</p>
                    <p className="text-xs text-slate-500 font-mono">{a.timestamp} · {a.sublabel}</p>
                  </div>
                  <StatusPill status={a.status} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── STAFF MOBILE INTERFACE ──────────────────────────────────────────────────
function StaffMobile({ alerts, onCodeBlue, codeBlueActive }) {
  const [dismissed, setDismissed] = useState([]);
  const [confirming, setConfirming] = useState(false);
  const criticalAlert = alerts.find(a => a.type === "MEDICAL_FALL" && !dismissed.includes(a.id));
  const highAlert = alerts.find(a => a.type === "GLASS_BREAK" && !dismissed.includes(a.id));
  const activeAlert = criticalAlert || highAlert;

  const handleCodeBlue = async () => {
    setConfirming(true);
    await new Promise(r => setTimeout(r, 800));
    onCodeBlue(criticalAlert);
    setConfirming(false);
  };

  return (
    <div className="h-full flex items-center justify-center bg-slate-200 p-4">
      {/* Phone Shell */}
      <div className="relative w-[340px] h-[680px] bg-slate-800 rounded-[42px] shadow-2xl border-4 border-slate-700 overflow-hidden flex flex-col">
        {/* Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-28 h-7 bg-slate-800 rounded-b-2xl z-10 flex items-center justify-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-slate-600" />
          <div className="w-10 h-2 rounded-full bg-slate-900" />
        </div>

        <div className="flex-1 bg-white overflow-hidden flex flex-col">
          {/* Status Bar */}
          <div className="h-10 bg-white flex items-end pb-1 px-5 pt-6">
            <div className="flex items-center justify-between w-full">
              <span className="text-xs font-bold text-slate-900 font-mono">9:41</span>
              <div className="flex items-center gap-1">
                <Signal size={11} className="text-slate-900" />
                <Wifi size={11} className="text-slate-900" />
                <Battery size={11} className="text-slate-900" />
              </div>
            </div>
          </div>

          {/* App Header */}
          <div className={`px-4 py-3 border-b transition-colors duration-500 ${activeAlert && activeAlert.type === "MEDICAL_FALL" ? "bg-red-600" : activeAlert ? "bg-orange-500" : "bg-slate-900"}`}>
            <div className="flex items-center gap-2">
              <Shield size={16} className="text-white" />
              <span className="text-white font-bold text-sm tracking-wide">HotelGuard Staff</span>
              <div className="ml-auto flex items-center gap-1">
                {activeAlert && <span className="w-2 h-2 rounded-full bg-white animate-ping" />}
                <span className="text-white/80 text-xs font-mono">GH MERIDIAN</span>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto">
            {/* Code Blue Active State */}
            {codeBlueActive ? (
              <div className="p-4 space-y-3">
                <div className="rounded-2xl bg-red-50 border-2 border-red-200 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                    <span className="text-red-700 font-black text-sm tracking-widest">CODE BLUE ACTIVE</span>
                  </div>
                  <p className="text-red-600 text-xs font-medium mb-3">Hospital dispatch confirmed · ALS en route</p>
                  <div className="bg-white rounded-xl border border-red-100 p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <Building2 size={13} className="text-red-500" />
                      <span className="text-xs font-bold text-slate-800">Apollo Hospital</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-500">Emergency Wing</span>
                      <span className="text-xs font-mono font-bold text-red-600">~7 min ETA</span>
                    </div>
                  </div>
                </div>
                <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4">
                  <p className="text-xs font-bold text-slate-700 mb-3 uppercase tracking-wide">Your Action Items</p>
                  {[
                    "Guide ambulance to Gate 2",
                    "Clear floor 4 corridor",
                    "Do NOT move the patient",
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 mb-2">
                      <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                        <span className="text-red-600 font-bold text-xs">{i + 1}</span>
                      </div>
                      <span className="text-xs text-slate-600">{item}</span>
                    </div>
                  ))}
                </div>
                <div className="rounded-2xl bg-emerald-50 border border-emerald-200 p-3 flex items-center gap-2">
                  <CheckCircle size={16} className="text-emerald-500 flex-shrink-0" />
                  <p className="text-xs text-emerald-700 font-medium">Security Command Center has been notified</p>
                </div>
              </div>
            ) : activeAlert ? (
              <div className="p-4 space-y-3">
                {/* Flash Alert Card */}
                <div className={`rounded-2xl border-2 overflow-hidden ${activeAlert.type === "MEDICAL_FALL" ? "border-red-400 bg-red-50" : "border-orange-400 bg-orange-50"}`}>
                  <div className={`px-4 py-2 ${activeAlert.type === "MEDICAL_FALL" ? "bg-red-500" : "bg-orange-500"} flex items-center gap-2`}>
                    <Bell size={13} className="text-white" />
                    <span className="text-white text-xs font-black tracking-widest">
                      {activeAlert.type === "MEDICAL_FALL" ? "⚠ URGENT MEDICAL ALERT" : "⚠ SECURITY ALERT"}
                    </span>
                  </div>
                  <div className="p-4">
                    <p className={`font-black text-base mb-1 ${activeAlert.type === "MEDICAL_FALL" ? "text-red-800" : "text-orange-800"}`}>
                      {activeAlert.label}
                    </p>
                    <p className={`text-sm font-medium mb-3 ${activeAlert.type === "MEDICAL_FALL" ? "text-red-600" : "text-orange-600"}`}>
                      {activeAlert.sublabel}
                    </p>
                    <div className={`rounded-xl p-3 ${activeAlert.type === "MEDICAL_FALL" ? "bg-red-100" : "bg-orange-100"}`}>
                      <div className="grid grid-cols-2 gap-2">
                        {activeAlert.type === "MEDICAL_FALL" && (
                          <>
                            <div>
                              <p className="text-xs text-slate-500">Heart Rate</p>
                              <p className="text-sm font-mono font-bold text-red-700">38 bpm ⚠</p>
                            </div>
                            <div>
                              <p className="text-xs text-slate-500">Confidence</p>
                              <p className="text-sm font-mono font-bold text-red-700">97%</p>
                            </div>
                          </>
                        )}
                        <div>
                          <p className="text-xs text-slate-500">Detected At</p>
                          <p className="text-sm font-mono font-bold text-slate-700">{activeAlert.timestamp}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500">Sensor ID</p>
                          <p className="text-xs font-mono font-bold text-slate-700">{activeAlert.type === "MEDICAL_FALL" ? "PIR_FALL_412" : "ACOUSTIC_001"}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                {activeAlert.type === "MEDICAL_FALL" && (
                  <button
                    onClick={handleCodeBlue}
                    disabled={confirming}
                    className="w-full py-4 rounded-2xl bg-red-600 active:bg-red-800 text-white font-black text-lg tracking-widest shadow-lg shadow-red-500/30 transition-all duration-150 flex items-center justify-center gap-2 disabled:opacity-70"
                  >
                    {confirming ? (
                      <><RefreshCw size={18} className="animate-spin" /> DISPATCHING...</>
                    ) : (
                      <>
                        <HeartPulse size={20} />
                        CONFIRM — CODE BLUE
                      </>
                    )}
                  </button>
                )}
                <button
                  onClick={() => setDismissed(p => [...p, activeAlert.id])}
                  className="w-full py-3 rounded-2xl border-2 border-slate-200 text-slate-600 font-bold text-sm tracking-wide transition-all duration-150"
                >
                  Mark as False Alarm
                </button>
              </div>
            ) : (
              <div className="p-4 space-y-3">
                {/* Idle State */}
                <div className="rounded-2xl bg-emerald-50 border border-emerald-100 p-4 flex items-center gap-3">
                  <CheckCircle size={20} className="text-emerald-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-bold text-emerald-800">All Clear</p>
                    <p className="text-xs text-emerald-600">No active incidents</p>
                  </div>
                </div>
                <div className="rounded-2xl bg-slate-50 border border-slate-100 p-4">
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-3">My Shift — Active Protocols</p>
                  {["Floor 3–6 patrol complete", "Emergency exits checked", "AED units verified online"].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 mb-2">
                      <CheckCircle size={14} className="text-emerald-500" />
                      <span className="text-xs text-slate-600">{item}</span>
                    </div>
                  ))}
                </div>
                <div className="rounded-2xl bg-blue-50 border border-blue-100 p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Activity size={14} className="text-blue-500" />
                    <span className="text-xs font-bold text-blue-700">Sensor Grid Active</span>
                  </div>
                  <p className="text-xs text-blue-600">186 PIR sensors · 24 acoustic · All nominal</p>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Nav */}
          <div className="border-t border-slate-100 bg-white px-6 py-2 flex items-center justify-around">
            {[
              { icon: Bell, label: "Alerts", active: !!activeAlert },
              { icon: Radio, label: "Comm", active: false },
              { icon: MapPin, label: "Map", active: false },
              { icon: User, label: "Profile", active: false },
            ].map(({ icon: Icon, label, active }) => (
              <div key={label} className={`flex flex-col items-center gap-0.5 ${active ? "text-red-500" : "text-slate-400"}`}>
                <Icon size={18} />
                <span className="text-xs font-medium">{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Home Bar */}
        <div className="h-5 bg-slate-800 flex items-center justify-center">
          <div className="w-24 h-1 rounded-full bg-slate-600" />
        </div>
      </div>
    </div>
  );
}

// ─── SECURITY COMMAND CENTER ─────────────────────────────────────────────────
function CommandCenter({ incidents, codeBlueActive, alerts, etaSeconds, ambulanceStatus }) {
  const etaMin = Math.floor(etaSeconds / 60);
  const etaSec = etaSeconds % 60;
  const progress = codeBlueActive ? Math.max(0, 100 - (etaSeconds / 420) * 100) : 0;

  return (
    <div className="h-full bg-slate-950 text-slate-100 flex flex-col overflow-hidden">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-6 py-3 border-b border-slate-800 bg-slate-900/80 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Shield size={22} className="text-sky-400" />
            {codeBlueActive && <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />}
          </div>
          <div>
            <h1 className="font-mono font-black text-sm tracking-widest text-slate-100">SECURITY COMMAND CENTER</h1>
            <p className="text-xs text-slate-500 font-mono">Grand Hyatt Meridian, New Delhi · Shift: B</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          {codeBlueActive && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-1.5">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="text-red-400 font-mono font-bold text-xs tracking-widest">CODE BLUE ACTIVE</span>
            </div>
          )}
          <div className="flex items-center gap-1.5 text-xs font-mono text-slate-500">
            <Clock size={12} />
            <LiveClock />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden grid grid-cols-12 gap-0">
        {/* LEFT: Audit Trail */}
        <div className="col-span-4 border-r border-slate-800 flex flex-col overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-800">
            <h2 className="text-xs font-mono font-bold text-slate-400 tracking-widest uppercase">Active Incident Log</h2>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
            {incidents.length === 0 ? (
              <div className="text-center py-8">
                <CircleDot size={24} className="text-slate-800 mx-auto mb-2" />
                <p className="text-xs text-slate-600 font-mono">Awaiting incident trigger...</p>
              </div>
            ) : (
              incidents.map((inc, i) => (
                <div
                  key={inc.id}
                  className={`rounded-lg p-3 border transition-all duration-500 ${inc.type === "CRITICAL"
                    ? "border-red-500/30 bg-red-500/5"
                    : inc.type === "HIGH"
                      ? "border-orange-500/30 bg-orange-500/5"
                      : inc.type === "SUCCESS"
                        ? "border-emerald-500/30 bg-emerald-500/5"
                        : "border-slate-700/50 bg-slate-900/30"
                    }`}
                  style={{ animationDelay: `${i * 50}ms` }}
                >
                  <div className="flex items-start gap-2">
                    <div className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${inc.type === "CRITICAL" ? "bg-red-400" : inc.type === "HIGH" ? "bg-orange-400" : inc.type === "SUCCESS" ? "bg-emerald-400" : "bg-slate-500"}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs font-mono font-bold text-slate-200 truncate">{inc.label}</span>
                      </div>
                      <p className="text-xs text-slate-500 font-mono mt-0.5">{inc.detail}</p>
                      <p className="text-xs text-slate-600 font-mono mt-1">{inc.timestamp}</p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* MIDDLE: Map + ETA */}
        <div className="col-span-5 border-r border-slate-800 flex flex-col overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <h2 className="text-xs font-mono font-bold text-slate-400 tracking-widest uppercase">Live Situation Map</h2>
            {codeBlueActive && <StatusPill status="CODE_BLUE" />}
          </div>

          {/* Simulated Map */}
          <div className="relative bg-slate-900 flex-1 overflow-hidden">
            <SimulatedMap codeBlueActive={codeBlueActive} progress={progress} />
          </div>

          {/* ALS ETA Panel */}
          {codeBlueActive && (
            <div className="border-t border-slate-800 p-4 bg-slate-900/80">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Ambulance size={16} className="text-red-400" />
                  <span className="text-sm font-mono font-bold text-red-300">ALS AMBULANCE EN ROUTE</span>
                </div>
                <span className="text-xs font-mono text-slate-400">{ambulanceStatus}</span>
              </div>
              <div className="grid grid-cols-3 gap-3 mb-3">
                <div className="rounded-lg bg-slate-800 p-2 text-center border border-slate-700">
                  <p className="text-xs text-slate-500 font-mono">ETA</p>
                  <p className="text-lg font-mono font-black text-red-400">
                    {etaSeconds <= 0 ? "ARRIVED" : `${etaMin}:${etaSec.toString().padStart(2, "0")}`}
                  </p>
                </div>
                <div className="rounded-lg bg-slate-800 p-2 text-center border border-slate-700">
                  <p className="text-xs text-slate-500 font-mono">Origin</p>
                  <p className="text-xs font-mono font-bold text-slate-200">Apollo Hosp.</p>
                </div>
                <div className="rounded-lg bg-slate-800 p-2 text-center border border-slate-700">
                  <p className="text-xs text-slate-500 font-mono">Distance</p>
                  <p className="text-xs font-mono font-bold text-slate-200">3.2 km</p>
                </div>
              </div>
              <div className="h-2 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-orange-500 to-red-500 rounded-full transition-all duration-1000"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-xs text-slate-600 font-mono mt-1 text-right">{Math.round(progress)}% of route complete</p>
            </div>
          )}

          {!codeBlueActive && (
            <div className="border-t border-slate-800 p-4 bg-slate-900/50">
              <div className="flex items-center gap-2 text-slate-600">
                <Navigation size={14} />
                <span className="text-xs font-mono">No active ambulance dispatch · All hospital links nominal</span>
              </div>
            </div>
          )}
        </div>

        {/* RIGHT: Actions + Status */}
        <div className="col-span-3 flex flex-col overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-800">
            <h2 className="text-xs font-mono font-bold text-slate-400 tracking-widest uppercase">Action Items</h2>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {ACTION_ITEMS.map((item) => (
              <ActionItem key={item.id} item={item} active={codeBlueActive} />
            ))}
          </div>

          {/* Hospital API Status */}
          <div className="border-t border-slate-800 p-3">
            <p className="text-xs font-mono text-slate-500 uppercase tracking-widest mb-2">Hospital API Links</p>
            {HOSPITAL_PARTNERS.map(h => (
              <div key={h.id} className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5">
                  <div className={`w-1.5 h-1.5 rounded-full ${codeBlueActive && h.id === "apollo" ? "bg-red-400 animate-pulse" : "bg-emerald-400"}`} />
                  <span className="text-xs text-slate-400 font-mono">{h.name}</span>
                </div>
                <span className={`text-xs font-mono ${codeBlueActive && h.id === "apollo" ? "text-red-400 font-bold" : "text-emerald-500"}`}>
                  {codeBlueActive && h.id === "apollo" ? "DISPATCHED" : "STANDBY"}
                </span>
              </div>
            ))}
          </div>

          {/* API Payload Preview */}
          {codeBlueActive && (
            <div className="border-t border-slate-800 p-3">
              <p className="text-xs font-mono text-slate-500 uppercase tracking-widest mb-2">Last API Dispatch Payload</p>
              <div className="bg-slate-900 rounded-lg p-2.5 border border-emerald-500/20 font-mono text-xs">
                <p className="text-emerald-400">POST /v1/emergency/dispatch</p>
                <p className="text-slate-500 mt-1">{"{"}</p>
                <p className="text-slate-400 pl-2"><span className="text-sky-400">"incident"</span>: <span className="text-yellow-400">"CODE_BLUE"</span>,</p>
                <p className="text-slate-400 pl-2"><span className="text-sky-400">"location"</span>: <span className="text-yellow-400">"Room 412"</span>,</p>
                <p className="text-slate-400 pl-2"><span className="text-sky-400">"hospital"</span>: <span className="text-yellow-400">"Apollo"</span>,</p>
                <p className="text-slate-400 pl-2"><span className="text-sky-400">"als_required"</span>: <span className="text-orange-400">true</span></p>
                <p className="text-slate-500">{"}"}</p>
                <p className="text-emerald-500 mt-1">✓ 200 OK · 142ms</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── ACTION ITEM ─────────────────────────────────────────────────────────────
function ActionItem({ item, active }) {
  const [done, setDone] = useState(false);
  const Icon = item.icon;
  const urgency = active && item.priority === "CRITICAL";

  return (
    <div
      className={`rounded-lg border p-3 transition-all duration-300 cursor-pointer ${done ? "border-emerald-500/30 bg-emerald-500/5 opacity-60" : urgency ? "border-red-500/30 bg-red-500/5" : "border-slate-700 bg-slate-900/50 hover:border-slate-600"}`}
      onClick={() => setDone(p => !p)}
    >
      <div className="flex items-center gap-2">
        <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${done ? "bg-emerald-500/20" : urgency ? "bg-red-500/20" : "bg-slate-800"}`}>
          {done ? <CheckCircle size={14} className="text-emerald-400" /> : <Icon size={14} className={urgency ? "text-red-400" : "text-slate-400"} />}
        </div>
        <div className="flex-1 min-w-0">
          <p className={`text-xs font-medium truncate ${done ? "line-through text-slate-600" : urgency ? "text-red-300" : "text-slate-300"}`}>
            {item.text}
          </p>
          <span className={`text-xs font-mono ${item.priority === "CRITICAL" ? "text-red-500" : item.priority === "HIGH" ? "text-orange-500" : "text-slate-600"}`}>
            {item.priority}
          </span>
        </div>
      </div>
    </div>
  );
}

// ─── SIMULATED MAP ───────────────────────────────────────────────────────────
function SimulatedMap({ codeBlueActive, progress }) {
  return (
    <div className="relative w-full h-full bg-slate-950 overflow-hidden">
      {/* Grid lines */}
      <svg className="absolute inset-0 w-full h-full opacity-10" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#334155" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>

      {/* Roads */}
      <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
        <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#1e293b" strokeWidth="12" />
        <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#334155" strokeWidth="2" strokeDasharray="8 6" />
        <line x1="35%" y1="0" x2="35%" y2="100%" stroke="#1e293b" strokeWidth="10" />
        <line x1="35%" y1="0" x2="35%" y2="100%" stroke="#334155" strokeWidth="1.5" strokeDasharray="6 5" />
        <line x1="70%" y1="0" x2="70%" y2="100%" stroke="#1e293b" strokeWidth="8" />
        <line x1="70%" y1="0" x2="70%" y2="100%" stroke="#2d3748" strokeWidth="1" strokeDasharray="5 4" />
        <line x1="0" y1="25%" x2="100%" y2="25%" stroke="#1e293b" strokeWidth="6" />
        <line x1="0" y1="75%" x2="100%" y2="75%" stroke="#1e293b" strokeWidth="6" />

        {/* Hotel Block */}
        <rect x="42%" y="35%" width="18%" height="20%" rx="4" fill="#1e3a5f" stroke="#3b82f6" strokeWidth="1.5" opacity="0.8" />
        <text x="51%" y="46%" textAnchor="middle" fill="#93c5fd" fontSize="7" fontFamily="monospace" fontWeight="bold">GRAND HYATT</text>
        <text x="51%" y="52%" textAnchor="middle" fill="#60a5fa" fontSize="6" fontFamily="monospace">MERIDIAN</text>

        {/* Surrounding blocks */}
        {[[10, 15, 18, 25], [78, 15, 15, 20], [10, 60, 20, 22], [78, 60, 15, 18]].map(([x, y, w, h], i) => (
          <rect key={i} x={`${x}%`} y={`${y}%`} width={`${w}%`} height={`${h}%`} rx="3" fill="#0f172a" stroke="#1e293b" strokeWidth="1" />
        ))}

        {/* Hospital */}
        <rect x="5%" y="16%" width="17%" height="23%" rx="4" fill="#172a1a" stroke="#22c55e" strokeWidth="1.5" opacity="0.8" />
        <text x="13.5%" y="26%" textAnchor="middle" fill="#4ade80" fontSize="7" fontFamily="monospace" fontWeight="bold">APOLLO</text>
        <text x="13.5%" y="32%" textAnchor="middle" fill="#86efac" fontSize="6" fontFamily="monospace">HOSPITAL</text>

        {/* Ambulance Route */}
        {codeBlueActive && (
          <>
            <path
              d={`M 22% 27% L 35% 27% L 35% 50% L 42% 50%`}
              fill="none"
              stroke="#ef4444"
              strokeWidth="2.5"
              strokeDasharray="8 4"
              opacity="0.7"
            />
            {/* Ambulance position */}
            <circle
              cx={`${22 + progress * 0.2}%`}
              cy={`${27 - (progress > 50 ? (progress - 50) * 0.46 : 0)}%`}
              r="5"
              fill="#ef4444"
              stroke="#fca5a5"
              strokeWidth="2"
            >
              <animate attributeName="r" values="5;7;5" dur="1s" repeatCount="indefinite" />
            </circle>
          </>
        )}

        {/* Hotel Alert Marker */}
        {(codeBlueActive) && (
          <>
            <circle cx="51%" cy="45%" r="8" fill="#ef4444" opacity="0.3">
              <animate attributeName="r" values="8;16;8" dur="1.5s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.3;0;0.3" dur="1.5s" repeatCount="indefinite" />
            </circle>
            <circle cx="51%" cy="45%" r="5" fill="#ef4444" stroke="#fca5a5" strokeWidth="1.5" />
          </>
        )}

        {/* Labels */}
        <text x="51%" y="95%" textAnchor="middle" fill="#475569" fontSize="7" fontFamily="monospace">RING ROAD NORTH</text>
        <text x="8%" y="50%" textAnchor="middle" fill="#475569" fontSize="6" fontFamily="monospace" transform="rotate(-90, 30, 200)">DIPLOMATIC ENCLAVE MARG</text>
      </svg>

      {/* Legend */}
      <div className="absolute bottom-3 right-3 bg-slate-900/90 border border-slate-700 rounded-lg p-2 text-xs font-mono">
        {codeBlueActive && (
          <div className="flex items-center gap-1.5 mb-1">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-red-400">ALS En Route</span>
          </div>
        )}
        <div className="flex items-center gap-1.5 mb-1">
          <div className="w-2 h-2 rounded-full bg-blue-500" />
          <span className="text-slate-400">Grand Hyatt</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-emerald-500" />
          <span className="text-slate-400">Apollo Hospital</span>
        </div>
      </div>
    </div>
  );
}

// ─── LIVE CLOCK ─────────────────────────────────────────────────────────────
function LiveClock() {
  const [time, setTime] = useState(now());
  useEffect(() => {
    const t = setInterval(() => setTime(now()), 1000);
    return () => clearInterval(t);
  }, []);
  return <span>{time}</span>;
}

// ─── ROOT APP ────────────────────────────────────────────────────────────────
export default function App() {
  const [activeView, setActiveView] = useState("simulator");
  const [alerts, setAlerts] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [codeBlueActive, setCodeBlueActive] = useState(false);
  const [etaSeconds, setEtaSeconds] = useState(420);
  const [ambulanceStatus, setAmbulanceStatus] = useState("STANDBY");
  const etaRef = useRef(null);

  const addIncident = useCallback((label, detail, type = "INFO") => {
    setIncidents(p => [{ id: generateId(), label, detail, type, timestamp: now() }, ...p]);
  }, []);

  const handleTrigger = useCallback((alert) => {
    setAlerts(p => [alert, ...p]);
    setAlerts(p => p.map(a => a.id === alert.id ? { ...a, status: "ALERT" } : a));
    addIncident(
      `IoT Sensor Triggered`,
      `${alert.label} · ${alert.sublabel}`,
      alert.severity === "CRITICAL" ? "CRITICAL" : "HIGH"
    );
  }, [addIncident]);

  const handleCodeBlue = useCallback((alert) => {
    setCodeBlueActive(true);
    setAmbulanceStatus("DISPATCHED · MOVING");
    setEtaSeconds(420);

    // Update alert status
    if (alert) {
      setAlerts(p => p.map(a => a.id === alert.id ? { ...a, status: "CODE_BLUE" } : a));
    }

    addIncident("Staff Confirmed Emergency", "Code Blue declared · Room 412", "CRITICAL");
    setTimeout(() => addIncident("Hospital API Dispatched", "Apollo Emergency · ALS unit assigned · 200 OK", "SUCCESS"), 600);
    setTimeout(() => addIncident("ALS Ambulance Deployed", "Unit ALS-7 en route · ETA 7 min", "SUCCESS"), 1200);
    setTimeout(() => addIncident("Security Notified", "Gate 2 cleared · Elevator 3 locked", "INFO"), 1800);

    // ETA countdown
    if (etaRef.current) clearInterval(etaRef.current);
    etaRef.current = setInterval(() => {
      setEtaSeconds(prev => {
        if (prev <= 1) {
          clearInterval(etaRef.current);
          setAmbulanceStatus("ARRIVED AT GATE 2");
          addIncident("Ambulance Arrived", "ALS Unit at Gate 2 · Crew proceeding to Floor 4", "SUCCESS");
          return 0;
        }
        const next = prev - 1;
        if (next === 300) setAmbulanceStatus("2 MIN · APPROACHING RING ROAD");
        if (next === 120) setAmbulanceStatus("TURNING INTO PREMISES");
        if (next === 30) setAmbulanceStatus("AT GATE — CLEARING ENTRY");
        return next;
      });
    }, 1000);
  }, [addIncident]);

  const resetAll = () => {
    setAlerts([]);
    setIncidents([]);
    setCodeBlueActive(false);
    setEtaSeconds(420);
    setAmbulanceStatus("STANDBY");
    if (etaRef.current) clearInterval(etaRef.current);
  };

  const TABS = [
    { id: "simulator", label: "IoT Simulator", icon: Cpu, color: "violet" },
    { id: "staff", label: "Staff Mobile", icon: Smartphone, color: "slate", badge: alerts.filter(a => a.status !== "CODE_BLUE").length },
    { id: "command", label: "Command Center", icon: Shield, color: "sky", badge: codeBlueActive ? "LIVE" : null },
  ];

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col" style={{ fontFamily: "'IBM Plex Mono', 'Courier New', monospace" }}>
      <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;700&family=Barlow+Condensed:wght@400;600;700;800;900&display=swap" rel="stylesheet" />

      {/* Top Nav */}
      <div className="border-b border-slate-800 bg-slate-900/95 backdrop-blur sticky top-0 z-20">
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/40 flex items-center justify-center">
              <Siren size={16} className="text-red-400" />
            </div>
            <div>
              <span className="font-black text-white text-sm tracking-wider" style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "16px", letterSpacing: "0.1em" }}>RAPID CRISIS RESPONSE</span>
              <span className="text-slate-600 font-mono text-xs block" style={{ fontFamily: "inherit" }}>PLATFORM v2.1 · GRAND HYATT MERIDIAN</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {codeBlueActive && (
              <div className="flex items-center gap-2 bg-red-500/15 border border-red-500/40 rounded-lg px-3 py-1.5 animate-pulse">
                <HeartPulse size={14} className="text-red-400" />
                <span className="text-red-400 font-mono font-bold text-xs tracking-widest">CODE BLUE</span>
              </div>
            )}
            <button
              onClick={resetAll}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 text-slate-500 hover:text-slate-300 hover:border-slate-600 text-xs font-mono transition-colors"
            >
              <RefreshCw size={12} />
              RESET
            </button>
          </div>
        </div>

        {/* Tab Bar */}
        <div className="flex border-t border-slate-800">
          {TABS.map(tab => {
            const Icon = tab.icon;
            const active = activeView === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveView(tab.id)}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-mono font-bold tracking-wider transition-all duration-200 border-b-2 ${active
                  ? tab.id === "simulator" ? "border-violet-500 text-violet-400 bg-violet-500/5"
                    : tab.id === "staff" ? "border-white text-white bg-white/5"
                      : "border-sky-500 text-sky-400 bg-sky-500/5"
                  : "border-transparent text-slate-600 hover:text-slate-400 hover:bg-slate-800/50"
                  }`}
              >
                <Icon size={14} />
                {tab.label}
                {tab.badge != null && tab.badge !== 0 && (
                  <span className={`px-1.5 py-0.5 rounded text-xs font-bold ${typeof tab.badge === "string" ? "bg-red-500 text-white" : "bg-orange-500 text-white"}`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden" style={{ height: "calc(100vh - 96px)" }}>
        {activeView === "simulator" && (
          <IoTSimulator onTrigger={handleTrigger} activeAlerts={alerts} />
        )}
        {activeView === "staff" && (
          <StaffMobile alerts={alerts} onCodeBlue={handleCodeBlue} codeBlueActive={codeBlueActive} />
        )}
        {activeView === "command" && (
          <CommandCenter
            incidents={incidents}
            codeBlueActive={codeBlueActive}
            alerts={alerts}
            etaSeconds={etaSeconds}
            ambulanceStatus={ambulanceStatus}
          />
        )}
      </div>
    </div>
  );
}
